#include <iostream>
#include <vector>
#include <string>
#include <stdexcept>
#include <numeric>
#include <ctime>

struct person {
    std::string name;
    int birthyear;
    int age;
};

int countAgeMid(const std::vector<person>& group) {
    if (group.empty()) return 0;
    int sum = 0;
    for (const auto& p : group) {
        sum += p.age;
    }
    return sum / group.size();
}

int main() {
    std::vector<person> database;
    std::vector<person> underage, adult, elder;

    int currentyear = 2025; //can be executed with time() based calculating

    std::cout << "Input a name and birthyear (empty input will terminate):\n";

    while (true) {
        std::string name;
        std::cout << "Name: ";
        std::getline(std::cin, name);
        if(name.empty()) break;

        std::string input;
        int year;

        std::cout << "birthyear: ";
        std::getline(std::cin, input);

        try {
            year = std::stoi(input);
            int age = currentyear - year;

            if (year > currentyear)
                throw std::runtime_error("birthyear in future\n");
            if (age > 130) 
                throw std::runtime_error("age goes past 130 - not realistic\n");
            
            person p = {name, year, age};
            database.push_back(p);

            if (age < 18)
                underage.push_back(p);
            else if (age < 65)
                adult.push_back(p);
            else
                elder.push_back(p);
            
            std::cout << "\n--- backend log ---\n";
            std::cout << "Underaged: " << underage.size()
                      << ", age middle: " << countAgeMid(underage) << "\n";
            std::cout << "Adults: " << adult.size()
                      << ", age middle: " << countAgeMid(adult) << "\n";
            std::cout << "Elders: " << elder.size()
                      << ", age middle: " << countAgeMid(elder) << "\n";

            int commonMidAge = countAgeMid(database);
            std::cout << "Common age middle: " << commonMidAge << "\n";
        } catch (const std::exception& e) {
            std::cout << "Exception: " << e.what() << "n";
        }
    }

    std::cout << "\n--- persons in database ---\n";
    for (const auto& p : database) {
        std::cout << p.name << " (born " << p.birthyear << ", age " << p.age << ")\n";
    }

    return 0;
}