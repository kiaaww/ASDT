#include <cstdio>

int main() {
    // Declaring the unsigned char
    unsigned char i = 0;

    // printing a header before the loop starts
    printf("Printing an idex starts:\n");

    // infinite loop, unsigned char (0-255)
    while (true) {
        // Prints the current index value followed by newline
        printf("Index: %u\n", i);

        // increments the index
        i++;
    }
    return 0;
}