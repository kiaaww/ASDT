#include <iostream>
#include <string>
#include <unistd.h>     // fork, exec
#include <sys/wait.h>   // wait
#include <signal.h>     // kill
#include <vector>

pid_t index_pid = -1;

void printSelection() {
    std::cout << "\n--- Program runner ---\n";
    std::cout << "Choose a program to run:\n";
    std::cout << "1 - Printing an index (endless)\n";
    std::cout << "2 - Catalog of names\n";
    std::cout << "3 - number vector\n";
    std::cout << "4 - number types\n";
    std::cout << "5 - person database\n";
    std::cout << "6 - Terminate number 1\n";
    std::cout << "0 - Stop runner\n";
    std::cout << "Valinta: ";
}

void runProgram(const std::string& program, bool save_pid = false) {
    pid_t pid = fork();

    if (pid == 0) {
        // Child process
        if (save_pid) {
            // Detach from terminal
            setsid();

            // Redirect output
            freopen("/dev/null", "w", stdout);
            freopen("/dev/null", "w", stderr);
        }

        execl(("./" + program).c_str(), program.c_str(), (char*)nullptr);
        std::cerr << "Starting the program failed.\n";
        exit(1);
    } else if (pid > 0) {
        // Parent process
        if (save_pid) {
            index_pid = pid;
            std::cout << "Task 1 started as a background process: " << pid << "\n";
        } else {
            waitpid(pid, nullptr, 0); // Wait for other tasks
        }
    } else {
        std::cerr << "fork() failed\n";
    }
}

int main() {
    while (true) {
        printSelection();

        std::string choice;
        std::getline(std::cin, choice);

        if (choice == "0") {
            std::cout << "Runner stopping\n";
            break;
        } else if (choice == "1") {
            runProgram("index", true);
        } else if (choice == "2") {
            runProgram("namecatalog");
        } else if (choice == "3") {
            runProgram("vector");
        } else if (choice == "4") {
            runProgram("numbers");
        } else if (choice == "5") {
            runProgram("persons");
        } else if (choice == "6") {
            if  (index_pid > 0) {
                kill(index_pid, SIGTERM);
                std::cout << "Number 1 process (" << index_pid << ") has stopped\n";
                index_pid = -1;
            } else {
                std::cout << "number 1 is not in process\n";
            }
        } else {
            std::cout << "incorrect choice\n";
        }
    }
    return 0;
}