#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>

int main() {
    std::vector<int> numbers;
    int number;

    std::cout << "Input numbers (empty input will terminate): \n";

    while (true) {
        std::cout << "Number: ";
        std::string input;
        std::getline(std::cin, input);

        if (input.empty()) break;

        try {
            number = std::stoi(input);
            numbers.push_back(number);
        } catch (...) {
            std::cout << "Error in input, try again.\n";
        }
    }

    if (numbers.empty()) {
        std::cout << "No numbers.\n";
        return 0;
    }
    // arranged from smallest to biggest
    std::sort(numbers.begin(), numbers.end(), std::greater<int>());

    // Counting the amount, sum and mid
    int sum = std::accumulate(numbers.begin(), numbers.end(), 0);
    double mid = static_cast<double>(sum) / numbers.size();

    std::cout << "\nNumbers from biggest to smallest:\n";
    for (int n : numbers) {
        std::cout << n << " ";
    }
    std::cout << "\nAmount: " << numbers.size()
              << "\nSum: " << sum
              << "\nMid: " << mid << "\n";
    return 0;
}