#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>

int main() {
    std::vector<int> even;
    std::vector<int> odd;
    int num;

    std::cout << "Input numbers (empty input will terminate):\n";

    while (true) {
        std::cout << "Number: ";
        std::string input;
        std::getline(std::cin, input);

        if (input.empty()) break;

        try {
            num = std::stoi(input);
            if (num % 2 == 0)
                even.push_back(num);
            else
                odd.push_back(num);
        } catch (...) {
            std::cout << "Error in input, try again.\n";
        }
    }

    std::sort(even.begin(), even.end());
    std::sort(odd.begin(), odd.end());

    auto count = [](const std::vector<int>& v) {
        int sum = std::accumulate(v.begin(), v.end(), 0);
        double mid = v.empty() ? 0 : static_cast<double>(sum) / v.size();
        return std::make_pair(sum, mid);
    };

    auto [sumP, mdP] = count(even);
    auto [sumT, mdT] = count(odd);

        std::cout << "\nEven numbers:\n";
    for (int n : even) std::cout << n << " ";
    std::cout << "\nAmount: " << even.size()
              << "\nSum: " << sumP
              << "\nMid: " << mdP << "\n";

    std::cout << "\nOdd numbers:\n";
    for (int n : odd) std::cout << n << " ";
    std::cout << "\nAmount: " << odd.size()
              << "\nSum: " << sumT
              << "\nMid: " << mdT << "\n";

    return 0;
}