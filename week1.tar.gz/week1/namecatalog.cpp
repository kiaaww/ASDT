#include <iostream>
#include <set>
#include <string>
#include <stdexcept>

int main() {
    std::set<std::string> catalog;
    std::string name;
    
    std::cout << "give names (empty input will terminate):\n";

    // asks user for names
    while (true) {
        std::cout << "Name: ";
        std::getline(std::cin, name);

        if (name.empty()) break; //empty input will terminate
        catalog.insert(name); //adds name to catalog
    }

    // repeats for the whole catalog
    while (!catalog.empty()) {
        std::cout << "\n--- catalog space ---\n";
        
        // print names
        std::cout << "names in alphabetical order:\n";
        for (const auto& n : catalog) {
            std::cout << n << "\n";
        }

        //print amount 
        std::cout << "Amount of names: " << catalog.size() << "\n";

        try {
        if (catalog.size() == 1) {
                throw std::runtime_error("Only one remaining, can't delete two.");
            }
            if (catalog.empty()) {
                throw std::runtime_error("Empty catalog.");
            }

            // Poista ensimmäinen ja viimeinen
            auto first = catalog.begin();
            auto last = std::prev(catalog.end());

            std::cout << "Deleting: " << *first << " and " << *last << "\n";

            catalog.erase(first);
            catalog.erase(last);

        } catch (const std::runtime_error& e) {
            std::cout << "Exception: " << e.what() << "\n";
            break;
        }
    }

    std::cout << "\nEmpty catalog.\n";
    return 0;
}